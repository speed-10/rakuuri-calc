ラク売り計算 収益化準備ページ

GitHubリポジトリ speed-10/rakuuri-calc のルートに、about.html、guide.html、privacy.html を追加してください。既存の index.html は変更・削除しません。

公開後のURL:
https://speed-10.github.io/rakuuri-calc/about.html
https://speed-10.github.io/rakuuri-calc/guide.html
https://speed-10.github.io/rakuuri-calc/privacy.html

注意: 広告を実際に導入した場合は、プライバシーポリシーを広告サービスの実際の仕様に合わせて更新してください。現時点では公開用の連絡先が未設定です。収益化サービスへの申請前に、問い合わせ先と運営者情報の掲載方針を決めてください。
